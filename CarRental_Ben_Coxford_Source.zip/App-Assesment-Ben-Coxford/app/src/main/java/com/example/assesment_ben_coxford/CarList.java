package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class CarList extends AppCompatActivity {

    Spinner spinner; //Globalize the spinner.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_list);

        spinner = (Spinner) findViewById(R.id.spinner); //Set the spinner to the xml object.

        Intent intent = getIntent(); //Retrieve the intent.

        final String customerName = intent.getStringExtra("customerName"); //Store the customers name from the intents extras.

        File cars = new File(getApplicationContext().getFilesDir(), "cars.txt"); //Open the list of cars.

        Check(cars); //Uncomment when manually updating the text file.
        //Update(cars); //Uncomment to manually update the text file of cars. When doing so comment line 34.

        //Button to select a car.
        Button btn = (Button) findViewById(R.id.button5);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = spinner.getSelectedItem().toString(); //Get the selected item in the spinner.

                //Example: 1. Audi

                int indexLast = text.indexOf('.'); //Retrieve the index of the character '.'
                String id = text.substring(0, indexLast); //Retrieve the cars ID using the index.

                String car = text.substring(indexLast+1, text.length()-1); //Retrieve the cars name using the index and the length.

                String textFileName = id + ".txt"; //Form the name of the cars review text file.

                Intent intent = new Intent(CarList.this, Review.class);
                //Pass the cars review file name, car name and customer name.
                intent.putExtra("data", textFileName);
                intent.putExtra("carName", car);
                intent.putExtra("customerName", customerName);
                startActivity(intent);
            }
        });
    }

    public void Selected(List<String> array) {
        //Set up the spinner.
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, array);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    //Manually update the files automatically. Overwrites the entire file.
    public void Update(File cars) {
        String data =  "true-Benz Hatchback-Benz Hatchback with Power Locks and Windows, Air Bags and 4 Seats (£11/hr)\n"
                + "true-Toyota-Manual, Diesel Toyota with Air Conditioning and 8 Seats (£7/hr)\n"
                + "false-Honda-Automatic Honda with Air Conditioning, Power Locks/Windows, Airbags and 5 Seats (£9/hr)\n"
                + "true-Jaguar-Automatic Jaguar with Cruise Control, Leather Interior, Air Conditioning, Tilt Steering Wheel, Power Mirrors, Power Door Locks and 4 Seats (£10/hr)\n"
                + "true-Audi-Automatic Audi with Power Steering, Power Brakes, Locks and Windows, Air Bags, Air Conditioning, ABS Breaks and 2 Seats (£8/hr)\n";

        try {
            FileWriter stream = new FileWriter(cars, false); //Append set to false to overwrite the original file.
            stream.write(data);
            stream.close();
            Check(cars);
        }
        catch (Exception e) {
            ((TextView)(findViewById(R.id.textView9))).setText("There was an error loading the text");
        }
    }

    //Displays the cars.
    public void Check(File cars) {
        try {
            Scanner reader = new Scanner(cars);
            String s = "";

            List<String> availableCars = new ArrayList<>(); //Creates an array of available cars to initialise the spinner.

            int current = 1;
            while (reader.hasNextLine()) { //Continues to reads the file until the last line.
                String l = reader.nextLine(); //Reads the next line.
                String[] data = l.split("-"); //Splits the data of the car.
                if (data[0].equals("true")) { //If the value is equal to true (available)
                    s = s + String.valueOf(current) + ". " + data[2] + "\n\n"; //Add to the data.

                    String spinnerTicket = String.valueOf(current) + ". " + data[1];
                    availableCars.add(spinnerTicket); //Add to the spinner array.

                }
                else {
                    s = s + String.valueOf(current) + ". " + data[2] + " (Not Available)" +"\n\n"; //Note to the user the car is unavailable.
                }
                current++;
            }
            if(!s.isEmpty()) {
                Selected(availableCars); //Initialise the spinner with the array of available cars to select.
                ((TextView) (findViewById(R.id.textView9))).setText(s);
            }
            else {
               Update(cars);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            ((TextView)(findViewById(R.id.textView9))).setText("There was an error loading the text"); //display an error message on failure to read the file.
        }
    }
}
