package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;

public class UserReview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_review);

        Intent intent = getIntent();
        final String carData = intent.getStringExtra("carID"); //Store the cars ID.

        //Button to submit the review.
        Button btn = (Button) findViewById(R.id.button11);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String review = ((EditText) findViewById(R.id.editText16)).getText().toString();

                if(!review.isEmpty()) { //If the review is not emtpy.
                    String fileName = carData + ".txt"; //Get the cars review file.
                    File file = new File(getApplicationContext().getFilesDir(), fileName); //Open the review file.

                    try {
                        //Append the review to the end of the reviews file.
                        FileWriter stream = new FileWriter(file, true);
                        stream.append(review + "\n");
                        stream.close(); //Close the file.
                        Intent intent = new Intent(UserReview.this, CarList.class); //Return to the home page.
                        startActivity(intent);
                    }
                    catch (Exception e) {
                        Intent intent = new Intent(UserReview.this, CarList.class); //On an error, return to the list of cars.
                        startActivity(intent);
                    }
                }
                else {
                    ((TextView)(findViewById(R.id.textView35))).setText("Please enter a review!"); //Notify the user to enter a review
                }
            }
        });
    }


}
