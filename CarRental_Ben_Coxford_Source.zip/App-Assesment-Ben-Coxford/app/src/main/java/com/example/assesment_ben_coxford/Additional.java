package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Additional extends AppCompatActivity {

    //Array outlining the total cost for each refreshment.
    double[] total = {0,0,0,0,0,0,0};
    String carName; //Car name.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additional);

        Intent intent = getIntent();
        //Retrieve the data from the intent.
        final String[] data = intent.getStringArrayExtra("data");
        carName = intent.getStringExtra("carName");
        final String customerName = intent.getStringExtra("customerName");


        //
        //  Test each field, if they have changed or not. This allows the total to automatically update each time a refreshment is added or removed.
        //

        EditText edit = (EditText) findViewById(R.id.editText2);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString(); //Store the value.
                if(!TextUtils.isEmpty(s)) { //If the field is not empty.
                    double actualValue = Double.valueOf(value); //Cast the value to a double.
                    total[0] = actualValue * 1; //Multiply the quantity by the cost.
                    updateTotal(); //Update the total cost.
                }
                else {
                    total[0] = 0; //Update the total as no items if the field is empty.
                    updateTotal(); //Update the total (allows items to be removed from the running total)
                }
            }
        });

        //
        //      Repeat the process for each field.
        //

        EditText edit2 = (EditText) findViewById(R.id.editText4);
        edit2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[1] = actualValue * 1.2;
                    updateTotal();
                }
                else {
                    total[1] = 0;
                    updateTotal();
                }
            }
        });

        EditText edit3 = (EditText) findViewById(R.id.editText10);
        edit3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[2] = actualValue * 2;
                    updateTotal();
                }
                else {
                    total[2] = 0;
                    updateTotal();
                }
            }
        });

        EditText edit4 = (EditText) findViewById(R.id.editText11);
        edit4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[3] = actualValue * 0.5;
                    updateTotal();
                }
                else {
                    total[3] = 0;
                    updateTotal();
                }
            }
        });

        EditText edit5 = (EditText) findViewById(R.id.editText12);
        edit5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[4] = actualValue * 0.5;
                    updateTotal();
                }
                else {
                    total[4] = 0;
                    updateTotal();
                }
            }
        });

        EditText edit6 = (EditText) findViewById(R.id.editText13);
        edit6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[5] = actualValue * 0.5;
                    updateTotal();
                }
                else {
                    total[5] = 0;
                    updateTotal();
                }
            }
        });

        EditText edit7 = (EditText) findViewById(R.id.editText14);
        edit7.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String value = s.toString();
                if(!TextUtils.isEmpty(s)) {
                    double actualValue = Double.valueOf(value);
                    total[6] = actualValue * 1;
                    updateTotal();
                }
                else {
                    total[6] = 0;
                    updateTotal();
                }
            }
        });

        //Button to continue to the payment activity.
        Button btn2 = (Button) findViewById(R.id.button10);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Additional.this, Payment.class);

                //Finalise the users refreshments and store each value as a string in the array.
                String[] dataFinal = {String.valueOf(total[0]), String.valueOf(total[1]), String.valueOf(total[2]), String.valueOf(total[3]), String.valueOf(total[4]), String.valueOf(total[5]), String.valueOf(total[6])};

                //Pass the previous data and the new list of refreshments to the payment class.
                intent.putExtra("additionalData", dataFinal);
                intent.putExtra("carData", data);
                intent.putExtra("carName", carName);
                intent.putExtra("customerName", customerName);
                startActivity(intent); //Start the activity.
            }
        });
    }

    //Updates the total.
    public void updateTotal() {
        double sum = 0; //Sum or total of all the refreshments costs.
        for(Double i : total) {
            sum = sum + i;
        }

        ((TextView)(findViewById(R.id.textView16))).setText("Total: £" + String.valueOf(sum)); //Update the text view with the new total.
    }
}
