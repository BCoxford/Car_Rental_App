package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Review extends AppCompatActivity {

    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        Intent intent = getIntent();
        String fileName = intent.getStringExtra("data");
        final String carName = intent.getStringExtra("carName");
        final String customerName = intent.getStringExtra("customerName");

        int indexLast = fileName.indexOf('.');

        id = Integer.parseInt(fileName.substring(0, indexLast));

        File carReview = new File(getApplicationContext().getFilesDir(), fileName);

        //Update(carReview);
        Display(carReview);

        //Return to car list buttons.
        Button btn = (Button) findViewById(R.id.button6);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Review.this, CarList.class); //Return to the list of cars.
                startActivity(intent);
            }
        });

        //Continue to the cars details.
        Button btn2 = (Button) findViewById(R.id.button7);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Review.this, Details.class);

                //Pass the ID of the car, the car name and the customers name.
                intent.putExtra("data", String.valueOf(id));
                intent.putExtra("carName", carName);
                intent.putExtra("customerName", customerName);
                startActivity(intent); //Start the activity.
            }
        });
    }

    //Manually update and initialise the cars review files. Only required once to create the file.
    public void Update(File cars) {

        try {
            FileWriter stream = new FileWriter(cars, false);
            stream.write("");
            stream.close();
            Display(cars);
        }
        catch (Exception e) {
            ((TextView)(findViewById(R.id.textView13))).setText("There was an error loading the text");
        }
    }

    //Display the cars reviews.
    public void Display(File cars) {
        try {
            Scanner reader = new Scanner(cars);
            String s = "";

            while (reader.hasNextLine()) { //Read each line and add to string.
                String l = reader.nextLine();
                s = s + l + "\n";
            }

            reader.close(); //Close the scanner.

            ((TextView)(findViewById(R.id.textView13))).setText(s); //Display all of the reviews.
        }
        catch (Exception e) {
            e.printStackTrace();
            ((TextView)(findViewById(R.id.textView13))).setText("There was an error loading the reviews");
        }
    }
}
