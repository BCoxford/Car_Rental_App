package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    File file1; //Global variable file.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        file1 = new File(getApplicationContext().getFilesDir(), "accounts.txt"); //Open the accounts file.

        //Registration button.
        Button btn = (Button) findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, register.class); //Intent linked to the registration activity.
                startActivity(intent);
            }
        });

        //Login button.
        Button btn2 = (Button) findViewById(R.id.button);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Retrieve username and password fields.
                String username = ((EditText) findViewById(R.id.editText)).getText().toString();
                String pass = ((EditText) findViewById(R.id.editText3)).getText().toString();

                try {
                    Scanner reader = new Scanner(file1); //Open the accounts file.
                    String s = "";
                    String[] data ={"a"};

                    boolean Found = false;
                    while (reader.hasNextLine() && Found == false) { //Read the next line until the user is found.
                        s = reader.nextLine(); //Read the next line.
                        data = s.split(","); //Split the data into an array.
                        if(username.equals(data[1])) { //Test if the username entered is equal to the current username.
                            Found = true; //If so set found to true.
                        }
                    }

                    //If no user is found, the user must not exist.
                    if(Found == false && data.length > 2) {
                        ((TextView)(findViewById(R.id.textView2))).setText("That username does not exist!");
                    }
                    else {
                        if (pass.equals(data[2])) { //If the password is valid.
                            if(data[3].equals("false")) { //If the user does not have a current receipt.
                                Intent intent = new Intent(MainActivity.this, CarList.class); //Start the car list activity.
                                intent.putExtra("customerName", data[0]); //Pass the customers name through.
                                startActivity(intent);
                            }
                            else {
                                Intent intent = new Intent(MainActivity.this, Receipt.class); //Customer has a receipt already.
                                startActivity(intent);
                            }
                        } else {
                            //Incorrect password message.
                            ((TextView)(findViewById(R.id.textView2))).setText("Incorrect password!");
                        }
                    }
                }
                catch (Exception e) { //Throws exception message and displays it.
                    ((TextView)(findViewById(R.id.textView2))).setText("There was an error!");
                }
            }
        });
    }
}
