package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Details extends AppCompatActivity {

    int priceInt = -1; //Price per hour.
    int total = -1; //Total cost
    int hours = 0; //Number of hours selected.
    String carName; //The cars name.
    int carID = 0; //The cars ID.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        //Retrieve all the details from previous intents.
        Intent intent = getIntent();
        String car = intent.getStringExtra("data");
        carName = intent.getStringExtra("carName");
        final String customerName = intent.getStringExtra("customerName");

        carID = Integer.parseInt(car); //Get the cars ID as an integer.

        File carReview = new File(getApplicationContext().getFilesDir(), "cars.txt");

        try {

            //Retrieve all of the cars details.

            FileReader inp = new FileReader(carReview);
            BufferedReader scanner = new BufferedReader(inp);

            String[] allLines = {"","","","",""};

            int len = 5; //Length of file in lines.

            for(int i=0; i<len; i++) {
                allLines[i] = scanner.readLine();
            }

            int arrayID = carID-1; //Cars ID indexed from zero. 1 = 0 (1-1) for index 0.

            String[] details = allLines[arrayID].split("-"); //Split the string of the selected car into an array.

            //Price example: (£2/hr)
            int indexFirst = details[2].indexOf('('); //First index
            int indexLast = details[2].indexOf(')'); //Last index

            String price = details[2].substring(indexFirst + 1, indexLast); //Retrieve the price per hour.

            //Price example as integer: £2/
            indexFirst = details[2].indexOf('£'); //First index.
            indexLast = details[2].indexOf('/'); //Last index.

            priceInt = Integer.parseInt(details[2].substring(indexFirst + 1, indexLast)); //The price per hour as an integer.

            String spec = details[2].substring(0, indexFirst - 1);

            //Display details.
            ((TextView) (findViewById(R.id.textView5))).setText("Car: " + details[1]);
            ((TextView) (findViewById(R.id.textView10))).setText("Spec: " + spec);
            ((TextView) (findViewById(R.id.textView11))).setText("Price: " + price);

            scanner.close(); //Close scanner
        }
        catch (Exception e) { //Catch any exceptions and print them to the console.
            e.printStackTrace();
        }

        //Button to return to the list of cars.
        Button btn = (Button) findViewById(R.id.button9);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Details.this, CarList.class);
                startActivity(intent);
            }
        });

        //Button to book the car. Note the car is available still until the point of payment.
        Button btn2 = (Button) findViewById(R.id.button8);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(total != -1) { //If a total has been entered.
                    Intent intent = new Intent(Details.this, Additional.class); //Continue to additional refreshments.
                    String[] data = {String.valueOf(total), String.valueOf(hours), String.valueOf(carID)};
                    intent.putExtra("data", data);
                    intent.putExtra("carName", carName);
                    intent.putExtra("customerName", customerName);
                    startActivity(intent);
                }
            }
        });

        //Automatically updates the price when the text is changed within the field.
        EditText edit = (EditText) findViewById(R.id.editText5);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //N/A but required.
            }

            //Text has changed.
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String hours = s.toString();
                if(!TextUtils.isEmpty(hours)) { //If the field is not empty.
                    int hoursInt = Integer.parseInt(hours);
                    if (priceInt != -1) {
                        UpdateTotal(hoursInt, priceInt); //Update the total.
                    }
                }
                else {
                    ((TextView)(findViewById(R.id.textView12))).setText("Enter the number of hours!"); //The field is empty.
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                //N/A but required.
            }
        });
    }

    //Calculates the total price for the vehicle hire.
    public void UpdateTotal(int hour, int price) {
        total = 0;
        total = hour*priceInt;
        hours = hour;
        ((TextView)(findViewById(R.id.textView12))).setText("Total: £" + String.valueOf(total));
    }
}
