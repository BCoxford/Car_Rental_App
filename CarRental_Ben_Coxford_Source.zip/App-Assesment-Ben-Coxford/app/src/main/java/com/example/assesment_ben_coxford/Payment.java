package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Payment extends AppCompatActivity {

    double sum = 0; //Total cost of refreshments.
    double car = 0; //Car rental hours in total.
    double total = 0; //Total cost of rental cost and refreshments.
    double discount = 0; //Discount amount.
    double additional = 0; //Cost of additional refreshments.
    double x = 0; //Random discount value 1-50

    String[] additionalData;
    String carName;
    String[] carData;
    String customerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        //Store all the data from previous intents.
        Intent intent = getIntent();
        carData = intent.getStringArrayExtra("carData");
        additionalData = intent.getStringArrayExtra("additionalData");
        carName = intent.getStringExtra("carName");
        customerName = intent.getStringExtra("customerName");

        //Display the cost of the rental and the amount of hours for.
        ((TextView)(findViewById(R.id.textView20))).setText("Car Rental: £" + carData[0] + " for " + carData[1] + " hours");

        //Sum the cost of the refreshments.
        for(String i : additionalData) {
            double a = Double.valueOf(i);
            sum = sum + a;
        }

        additional = sum;

        car = Double.valueOf(carData[0]);

        ((TextView)(findViewById(R.id.textView21))).setText("Additional Refreshments: £" + String.valueOf(sum));

        sum = sum + Double.valueOf(carData[0]); //Add the cost of the rental to the refreshments cost.

        //Randomly select a discount value from 1-51.
        x = Math.random()*51;

        //Convert the percentage to a decimal value and calculate the discount total.
        discount = sum*(x/100);

        //Round the discount to 0 decimal places.
        double scale = Math.pow(10, 0);
        x = Math.round(x*scale)/scale;

        scale = Math.pow(10, 2); //Update the round to two decimal places.
        discount = Math.round(discount*scale)/scale;

        //Update the text views with the discount and the discount amount.
        ((TextView)(findViewById(R.id.textView17))).setText("Discount of " + String.valueOf(x) + "%");
        ((TextView)(findViewById(R.id.textView22))).setText("Discount of " + String.valueOf(x) + "%: £" + String.valueOf(discount));

        //Calculate the final total value.
        total = sum - discount;

        //Round the total value to 2 decimal places.
        total = Math.round(total*scale)/scale;

        //Display the final total to the customer.
        ((TextView)(findViewById(R.id.textView23))).setText("Total: £" + String.valueOf(total));

        //Button to pay.
        Button btn2 = (Button) findViewById(R.id.button12);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String amountString = ((EditText) findViewById(R.id.editText15)).getText().toString(); //Retrieves the amount the customer wishes to pay.

                //Tests if the amount entered is not empty.
                if(!amountString.isEmpty()) {
                    Double amount = Double.parseDouble(amountString);
                    if(amount >= total) {
                        int carID = Integer.valueOf(carData[2]);
                        int arrayID = carID - 1;
                        double change = amount - total; //Calculate the change needed.
                        UpdateFile(arrayID, change); //Update the file with the new data.
                    }
                    else {
                        //Notify the user they have not entered enough to pay.
                        ((TextView)(findViewById(R.id.textView33))).setText("You have not entered enough for a payment to be made!");
                    }
                }
                else {
                    //A user has not entered a value.
                    ((TextView)(findViewById(R.id.textView33))).setText("Please enter the amount you wish to pay!");
                }
            }
        });

    }

    //Update the file.
    public void UpdateFile(int line, double change) {
        File carReview = new File(getApplicationContext().getFilesDir(), "cars.txt");

        try {

            FileReader inp = new FileReader(carReview);
            BufferedReader scanner = new BufferedReader(inp);

            String[] allLines = {"","","","",""};

            int len = 5; //Length of file in lines.

            for(int i=0; i<len; i++) {
                allLines[i] = scanner.readLine(); //Reads all the lines.
            }

            scanner.close(); //Closes the scanner.

            String[] details = allLines[line].split("-"); //Splits the lines of the current selected car.

            allLines[line] = "false-"+details[1]+"-"+details[2]; //Changes the availability of the car to false.

            String newData = allLines[0]+"\n"+allLines[1]+"\n"+allLines[2]+"\n"+allLines[3]+"\n"+allLines[4]; //Concatenates all previous lines and updates the file with the new line.

            try {
                //Re-writes the entire file with the updated availability.
                FileWriter stream = new FileWriter(carReview, false);
                stream.write(newData);
                stream.close();
            }
            catch (Exception e) {
                ((TextView)(findViewById(R.id.textView12))).setText("There was an error loading the text");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(Payment.this, Receipt.class); //Intent linked to the receipt activity.

        double[] totals = {car, additional, sum, x, discount, total}; //Creates an array with a list of totals.
        String[] carDat = {carData[0], carData[1], carData[2]};

        //Passes all the previous and new data to the receipt activity.
        intent.putExtra("totals", totals);
        intent.putExtra("carData", carDat);
        intent.putExtra("change", String.valueOf(change));
        intent.putExtra("additionalData", additionalData);
        intent.putExtra("carName", carName);
        intent.putExtra("customerName", customerName);
        startActivity(intent);
    }
}
