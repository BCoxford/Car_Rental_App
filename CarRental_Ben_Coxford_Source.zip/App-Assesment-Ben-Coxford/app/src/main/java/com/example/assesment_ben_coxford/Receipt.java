package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.concurrent.TimeUnit;

public class Receipt extends AppCompatActivity {

    boolean active = false; //Set to true to bypass the timer (removes the timer to return).
    String[] carData;
    int carID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        //Stores all the data from previous intents.
        Intent intent = getIntent();
        double[] totals = intent.getDoubleArrayExtra("totals");
        carData = intent.getStringArrayExtra("carData");
        String change = intent.getStringExtra("change");
        String customerName = intent.getStringExtra("customerName");
        carID = Integer.parseInt(carData[2]);

        double changeVal = Double.parseDouble(change);

        String[] additionalData = intent.getStringArrayExtra("additionalData");
        String carName = intent.getStringExtra("carName");

        double scale = Math.pow(10, 2); //Round to 2 decimals.
        change = String.valueOf(Math.round(changeVal*scale)/scale); //Round the change to two decimals.

        //Display all the data.

        ((TextView)(findViewById(R.id.textView25))).setText("Car: " + carName);
        ((TextView)(findViewById(R.id.textView26))).setText("Hours Booked: " + carData[1]);
        ((TextView)(findViewById(R.id.textView27))).setText("Rental Cost: £" + totals[0]);
        ((TextView)(findViewById(R.id.textView38))).setText("Change: £" + change);
        ((TextView)(findViewById(R.id.textView39))).setText("Customer: " + customerName);

        //Retrieves the number of each refreshments using

        String numCake = String.valueOf(Double.valueOf(additionalData[0])/1);
        String numBisc = String.valueOf(Double.valueOf(additionalData[1])/1.2);
        String numSand = String.valueOf(Double.valueOf(additionalData[2])/2);
        String numSweet = String.valueOf(Double.valueOf(additionalData[3])/0.5);
        String numChoc = String.valueOf(Double.valueOf(additionalData[4])/0.5);
        String numWater = String.valueOf(Double.valueOf(additionalData[5])/0.5);
        String numJuice = String.valueOf(Double.valueOf(additionalData[6])/1);

        //Concatenate all of the refreshments to a single string.
        String s = numCake + " Cake(s)\n " + numBisc + " Biscuit(s)\n " + numSand + " Sandwich(es)\n " + numSweet + " Sweet(s)\n " + numChoc + " Chocolate(s)\n " + numWater + " Bottle of Water(s)\n " + numJuice + " Juice Carton(s)\n";

        //Display the refreshments and the remaining values.
        ((TextView)(findViewById(R.id.textView24))).setText("Refreshments: \n" + s);
        ((TextView)(findViewById(R.id.textView28))).setText("Refreshments Cost: £" + totals[1]);
        ((TextView)(findViewById(R.id.textView29))).setText("Total (No Discount): £" + totals[2]);
        ((TextView)(findViewById(R.id.textView30))).setText(totals[3] + "% Discount: £" + totals[4]);
        ((TextView)(findViewById(R.id.textView31))).setText("Total: £" + totals[5]);

        //Retrieve the number of hours
        long hours = Long.valueOf(carData[1]);

        //Convert the hours to milliseconds.
        long milli = TimeUnit.HOURS.toMillis(hours);

        //Set a countdown timer with the time in milliseconds and the interval (every minute).
        new CountDownTimer(milli, 60000) {

            public void onTick(long milliFinished) { //Update the timer each interval.
                long minsLeftFinished = TimeUnit.MILLISECONDS.toMinutes(milliFinished);
                ((TextView)(findViewById(R.id.textView32))).setText("Minutes Left until Return: " + minsLeftFinished);
            }

            public void onFinish() { //Once the timer has finished set active to true to allow the user to return the vehicle.
                ((TextView)(findViewById(R.id.textView32))).setText("Return the car!");
                active = true;
            }
        }.start(); //Start the timer.

        //Button to return the car.
        Button btn = (Button) findViewById(R.id.button13);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(active) {
                    UpdateFile(carID);
                }
            }
        });
    }

    //Update the file of the car.
    public void UpdateFile(int line) {
        File carReview = new File(getApplicationContext().getFilesDir(), "cars.txt");

        int index = line-1; //get the index of the car.

        try {

            FileReader inp = new FileReader(carReview);
            BufferedReader scanner = new BufferedReader(inp);

            String[] allLines = {"","","","",""};

            for(int i=0; i<5; i++) {
                allLines[i] = scanner.readLine(); //Read all of the lines.
            }

            scanner.close(); //Close the reader.

            String[] details = allLines[index].split("-"); //Split the data of the current car.

            allLines[index] = "true-"+details[1]+"-"+details[2]; //Set the current cars availability to true (available).

            String newData = allLines[0]+"\n"+allLines[1]+"\n"+allLines[2]+"\n"+allLines[3]+"\n"+allLines[4]; //Concatenate all the lines to a single string.

            try {
                //Update and rewrite the file with the updated availability.
                FileWriter stream = new FileWriter(carReview, false);
                stream.write(newData);
                stream.close(); //Close the file.
            }
            catch (Exception e) {
                ((TextView)(findViewById(R.id.textView12))).setText("There was an error loading the text"); //Error message with any errors writing to the file.
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(Receipt.this, UserReview.class); //Continue to the user review page so a user can review the car they have just returned.
        intent.putExtra("carID", String.valueOf(carID)); //Pass the cars ID.
        startActivity(intent);
    }
}
