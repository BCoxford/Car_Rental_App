package com.example.assesment_ben_coxford;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;

public class register extends AppCompatActivity {

    File file1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        file1 = new File(getApplicationContext().getFilesDir(), "accounts.txt"); //Retrieves the file for accounts. If one is not present, a file will be created.

        //Button to register an account. Calls addAccount().
        Button btn = (Button) findViewById(R.id.button3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAccount(v);
            }
        });

        //Button to return to the login page.
        Button btn2 = (Button) findViewById(R.id.button4);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(register.this, MainActivity.class); //Intent linked to the login page.
                startActivity(intent);
            }
        });

    }

    //Method to check, validate and append an account.
    public void addAccount(View v) {
        //Retrieves text from each field.
        String name = ((EditText) findViewById(R.id.editText6)).getText().toString();
        String username = ((EditText) findViewById(R.id.editText7)).getText().toString();
        String pass = ((EditText) findViewById(R.id.editText8)).getText().toString();
        String pass2 = ((EditText) findViewById(R.id.editText9)).getText().toString();

        try {
            if((!pass.isEmpty()) && !pass2.isEmpty() && pass.equals(pass2)) { //Tests if the passwords are both entered and they match each other.
                if (!name.isEmpty()) { //Tests if the name is not empty.
                    if (!username.isEmpty()) { //Tests if the username not empty.
                        if(pass.length() >= 8) { //Tests the passwords length is equal or above 8.
                            String text = name + "," + username + "," + pass + "," + "false"; //Combines all the data to be stored on a line.
                            try {
                                FileWriter stream = new FileWriter(file1, true); //Open file for writing in append mode.
                                stream.append(text + "\n"); //Append the text to the file.
                                stream.close(); //Close the file.

                                Toast.makeText(getApplicationContext(), username + " account has successfully been created", Toast.LENGTH_LONG).show(); //Notify the user the accounts been created.
                                Intent intent = new Intent(register.this, MainActivity.class); //Intent linked to login page.
                                startActivity(intent);
                            } catch (Exception e) {
                                ((TextView) (findViewById(R.id.textView7))).setText("Error! Please try again."); //Error message/logging.
                            }
                        }
                        //Errors messages outlining why the accounts could not be created.
                        else {
                            ((TextView)(findViewById(R.id.textView7))).setText("Your password must be 8 or more characters!");
                        }
                    }
                    else {
                        ((TextView)(findViewById(R.id.textView7))).setText("Enter a username please!");
                    }
                }
                else {
                    ((TextView)(findViewById(R.id.textView7))).setText("Enter your full name please!");
                }
            }
            else {
                ((TextView)(findViewById(R.id.textView7))).setText("Your passwords do not match!");
            }
        }
        catch (Exception e) {
            ((TextView)(findViewById(R.id.textView7))).setText("Error! Please try again.");
        }
    }
}
